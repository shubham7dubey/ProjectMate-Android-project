package com.example.project3;

public class project {
    private String name;
    project()
    {

    }

    public project(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
